// Konfigurasi pin berdasarkan gambar
const int buttonPin = 4; // Terhubung ke GPIO 4 ESP32
const int ledPin = 5;    // Terhubung ke GPIO 5 ESP32

// Variabel pelacak status
bool ledState = false;       // Memulai dengan kondisi LED mati (OFF)
int lastButtonState = LOW;   // Menyimpan status tombol sebelumnya

void setup() {
  Serial.begin(115200);
  
  pinMode(buttonPin, INPUT);
  pinMode(ledPin, OUTPUT);
  
  // Pastikan LED mati saat awal dinyalakan
  digitalWrite(ledPin, LOW);
  Serial.println("Sistem Toggle Siap!");
}

void loop() {
  // Baca status tombol saat ini
  int currentButtonState = digitalRead(buttonPin);

  // Deteksi transisi: Hanya merespons saat tombol BARU SAJA DITEKAN (LOW ke HIGH)
  if (lastButtonState == LOW && currentButtonState == HIGH) {
    // Balikkan status LED (OFF jadi ON, ON jadi OFF)
    ledState = !ledState;
    digitalWrite(ledPin, ledState ? HIGH : LOW);

    // Tampilkan informasi status di Serial Monitor
    if (ledState) {
      Serial.println("Tombol ditekan 1x -> LED Menyala (ON)");
    } else {
      Serial.println("Tombol ditekan 1x -> LED Padam (OFF)");
    }

    // Jeda debounce untuk mencegah pemicuan ganda akibat pantulan tombol
    delay(200);
  }

  // Simpan kondisi tombol untuk iterasi berikutnya
  lastButtonState = currentButtonState;
}